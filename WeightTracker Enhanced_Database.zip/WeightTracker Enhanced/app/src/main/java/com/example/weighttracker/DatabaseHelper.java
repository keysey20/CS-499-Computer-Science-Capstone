package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.text.SimpleDateFormat;
import java.text.ParsePosition;
import java.util.Date;
import java.util.Locale;
import java.security.SecureRandom;
import java.security.MessageDigest;
import java.security.GeneralSecurityException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.util.Base64;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 4;

    private static final String TABLE_WEIGHT = "weight_history";
    private static final String COL_ID = "id";
    private static final String COL_WEIGHT = "weight";
    private static final String COL_DATE = "date";
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT + " REAL NOT NULL CHECK(weight > 0), " +
                COL_DATE + " TEXT NOT NULL)";
        db.execSQL(createTable);
        db.execSQL("CREATE INDEX IF NOT EXISTS " +
                "idx_weight_date ON weight_history(date)");
        String createUsersTable = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)";

        db.execSQL(createUsersTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS users (" +
                    "username TEXT PRIMARY KEY, " +
                    "password TEXT)");
        }

        if (oldVersion < 3) {

            db.execSQL("ALTER TABLE weight_history " +
                    "RENAME TO weight_history_old");

            db.execSQL("CREATE TABLE weight_history (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "weight REAL NOT NULL " +
                    "CHECK(typeof(weight) IN ('real', 'integer') " +
                    "AND weight > 0), " +
                    "date TEXT NOT NULL)");

            db.execSQL("INSERT INTO weight_history (id, weight, date) " +
                    "SELECT id, CAST(weight AS REAL), date " +
                    "FROM weight_history_old");

            db.execSQL("DROP TABLE weight_history_old");

            db.execSQL("CREATE INDEX IF NOT EXISTS " +
                    "idx_weight_date ON weight_history(date)");
        }

        if (oldVersion < 4) {
            db.execSQL(
                    "UPDATE weight_history SET date = " +
                            "substr(date, 7, 4) || '-' || " +
                            "substr(date, 1, 2) || '-' || " +
                            "substr(date, 4, 2) " +
                            "WHERE date GLOB " +
                            "'[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]'"
            );
        }

    }


    public boolean addWeight(String weight, String date) {

        String normalizedDate = normalizeDate(date);

        if (normalizedDate == null) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT, weight);
        values.put(COL_DATE, normalizedDate);

        long result = db.insert(TABLE_WEIGHT, null, values);

        return result != -1;
    }


    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHT,
                null,
                null,
                null,
                null,
                null,
                COL_ID + " DESC"
        );
    }
    public Cursor getStartingWeight() {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHT,
                null,
                null,
                null,
                null,
                null,
                COL_ID + " ASC",
                "1"
        );
    }
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                TABLE_WEIGHT,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }


    public boolean updateWeight(int id, String weight, String date) {

        String normalizedDate = normalizeDate(date);

        if (normalizedDate == null) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT, weight);
        values.put(COL_DATE, normalizedDate);

        int result = db.update(
                TABLE_WEIGHT,
                values,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }


    // Register a new user in the SQLite database

    // Register a user with a securely hashed password
    public boolean registerUser(String username, String password) {

        if (username == null || username.trim().length() < 3 ||
                password == null || password.length() < 8) {
            return false;
        }

        try {
            String securedPassword = createPasswordHash(password);

            SQLiteDatabase db = getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(COL_USERNAME, username.trim());
            values.put(COL_PASSWORD, securedPassword);

            long result = db.insert(TABLE_USERS, null, values);

            return result != -1;

        } catch (GeneralSecurityException e) {
            return false;
        }
    }



    // Check whether the username and password match a registered user

    // Verify credentials and upgrade legacy passwords
    public boolean checkUser(String username, String password) {

        if (username == null || password == null) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();
        String storedPassword;

        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_PASSWORD},
                COL_USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null)) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            storedPassword = cursor.getString(0);
        }

        if (storedPassword == null) {
            return false;
        }

        try {
            if (storedPassword.startsWith("PBKDF2$")) {

                String[] parts = storedPassword.split("\\$");

                if (parts.length != 3) {
                    return false;
                }

                byte[] salt = Base64.decode(
                        parts[1], Base64.NO_WRAP);

                byte[] expectedHash = Base64.decode(
                        parts[2], Base64.NO_WRAP);

                byte[] actualHash = hashPassword(password, salt);

                return MessageDigest.isEqual(
                        expectedHash, actualHash);
            }

            // Upgrade an existing plaintext password
            // after successful authentication.
            if (storedPassword.equals(password)) {

                ContentValues values = new ContentValues();

                values.put(
                        COL_PASSWORD,
                        createPasswordHash(password));

                int updated = db.update(
                        TABLE_USERS,
                        values,
                        COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                        new String[]{username, storedPassword});

                return updated == 1;
            }

            return false;

        } catch (GeneralSecurityException |
                 IllegalArgumentException e) {
            return false;
        }
    }


    // Calculate statistical summaries of stored weight records
    public Cursor getWeightStatistics() {
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT COUNT(*) AS total_entries, " +
                        "AVG(weight) AS average_weight, " +
                        "MIN(weight) AS minimum_weight, " +
                        "MAX(weight) AS maximum_weight " +
                        "FROM " + TABLE_WEIGHT,
                null
        );
    }

    private String normalizeDate(String value) {
        if (value == null) {
            return null;
        }

        SimpleDateFormat inputFormat =
                new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        inputFormat.setLenient(false);

        ParsePosition position = new ParsePosition(0);
        Date parsedDate = inputFormat.parse(value, position);

        if (parsedDate == null ||
                position.getIndex() != value.length()) {
            return null;
        }

        SimpleDateFormat outputFormat =
                new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        return outputFormat.format(parsedDate);
    }

    // Retrieve weight records within a selected date range
    public Cursor getWeightsByDateRange(
            String startDate, String endDate) {

        String start = normalizeDate(startDate);
        String end = normalizeDate(endDate);

        if (start == null || end == null ||
                start.compareTo(end) > 0) {
            throw new IllegalArgumentException(
                    "Invalid date range");
        }

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHT,
                null,
                COL_DATE + " BETWEEN ? AND ?",
                new String[]{start, end},
                null,
                null,
                COL_DATE + " DESC, " + COL_ID + " DESC"
        );
    }


    private static final int HASH_ITERATIONS = 600000;
    private static final int KEY_LENGTH = 256;

    // Generate a unique random salt for each password
    private byte[] generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }

    // Derive a secure password hash using PBKDF2
    private byte[] hashPassword(
            String password, byte[] salt)
            throws GeneralSecurityException {

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                HASH_ITERATIONS,
                KEY_LENGTH
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256");

            return factory.generateSecret(spec).getEncoded();

        } finally {
            spec.clearPassword();
        }
    }

    // Encode the salt and hash for database storage
    private String createPasswordHash(String password)
            throws GeneralSecurityException {

        byte[] salt = generateSalt();
        byte[] hash = hashPassword(password, salt);

        return "PBKDF2$" +
                Base64.encodeToString(salt, Base64.NO_WRAP) +
                "$" +
                Base64.encodeToString(hash, Base64.NO_WRAP);
    }




}