
///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ============
// Manage the viewing of 3D objects within the viewport.
//
// Original author: Brian Battersby - SNHU Instructor
// CS-330 Computational Graphics and Visualization, November 1, 2023
//
// CS-499 Enhancement Two: Algorithms and Data Structures
// Added view-projection matrix access for frustum culling.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <iostream>

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;

    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    Camera* g_pCamera = nullptr;

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    bool bOrthographicProjection = false;
}

/***********************************************************
 * Constructor
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = nullptr;

    // CS-499: Initialize camera matrices.
    m_viewMatrix = glm::mat4(1.0f);
    m_projectionMatrix = glm::mat4(1.0f);

    g_pCamera = new Camera();

    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80.0f;
}

/***********************************************************
 * Destructor
 ***********************************************************/
ViewManager::~ViewManager()
{
    m_pShaderManager = nullptr;
    m_pWindow = nullptr;

    if (g_pCamera != nullptr)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

/***********************************************************
 * CreateDisplayWindow()
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
    const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        windowTitle,
        nullptr,
        nullptr);

    if (window == nullptr)
    {
        std::cout << "Failed to create GLFW window"
                  << std::endl;
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(window);

    glfwSetCursorPosCallback(
        window,
        &ViewManager::Mouse_Position_Callback);

    glfwSetScrollCallback(
        window,
        &ViewManager::Mouse_Scroll_Callback);

    glEnable(GL_BLEND);
    glBlendFunc(
        GL_SRC_ALPHA,
        GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;

    return window;
}

/***********************************************************
 * Mouse_Position_Callback()
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
    GLFWwindow* window,
    double xMousePos,
    double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset =
        static_cast<float>(xMousePos) - gLastX;

    float yOffset =
        gLastY - static_cast<float>(yMousePos);

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    if (g_pCamera != nullptr)
    {
        g_pCamera->ProcessMouseMovement(
            xOffset,
            yOffset);
    }
}

/***********************************************************
 * Mouse_Scroll_Callback()
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
    GLFWwindow* window,
    double xOffset,
    double yOffset)
{
    if (g_pCamera != nullptr)
    {
        g_pCamera->ProcessMouseScroll(
            static_cast<float>(yOffset));
    }
}

/***********************************************************
 * ProcessKeyboardEvents()
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    if (m_pWindow == nullptr)
    {
        return;
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(
            m_pWindow,
            true);
    }

    // Switch between projection modes.
    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_P) == GLFW_PRESS)
    {
        bOrthographicProjection = false;
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_O) == GLFW_PRESS)
    {
        bOrthographicProjection = true;
    }

    if (g_pCamera == nullptr)
    {
        return;
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_W) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(
            FORWARD,
            gDeltaTime);
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_S) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(
            BACKWARD,
            gDeltaTime);
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_A) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(
            LEFT,
            gDeltaTime);
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_D) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(
            RIGHT,
            gDeltaTime);
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_Q) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(
            UP,
            gDeltaTime);
    }

    if (glfwGetKey(
        m_pWindow,
        GLFW_KEY_E) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(
            DOWN,
            gDeltaTime);
    }
}

/***********************************************************
 * PrepareSceneView()
 *
 * Update the camera view and projection matrices
 * for the current frame.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    if (g_pCamera == nullptr)
    {
        return;
    }

    float currentFrame =
        static_cast<float>(glfwGetTime());

    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    ProcessKeyboardEvents();

    // CS-499 ENHANCEMENT:
    // Store the current camera view matrix.
    m_viewMatrix = g_pCamera->GetViewMatrix();

    // Use the actual framebuffer aspect ratio.
    int framebufferWidth = WINDOW_WIDTH;
    int framebufferHeight = WINDOW_HEIGHT;

    if (m_pWindow != nullptr)
    {
        glfwGetFramebufferSize(
            m_pWindow,
            &framebufferWidth,
            &framebufferHeight);
    }

    if (framebufferHeight <= 0)
    {
        framebufferHeight = 1;
    }

    float aspectRatio =
        static_cast<float>(framebufferWidth) /
        static_cast<float>(framebufferHeight);

    // CS-499 ENHANCEMENT:
    // Store the current projection matrix.
    if (bOrthographicProjection)
    {
        m_projectionMatrix = glm::ortho(
            -10.0f,
            10.0f,
            -10.0f,
            10.0f,
            0.1f,
            100.0f);
    }
    else
    {
        m_projectionMatrix = glm::perspective(
            glm::radians(g_pCamera->Zoom),
            aspectRatio,
            0.1f,
            100.0f);
    }

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(
            g_ViewName,
            m_viewMatrix);

        m_pShaderManager->setMat4Value(
            g_ProjectionName,
            m_projectionMatrix);

        m_pShaderManager->setVec3Value(
            "viewPosition",
            g_pCamera->Position);
    }
}

/***********************************************************
 * GetViewProjectionMatrix()
 *
 * CS-499 ENHANCEMENT:
 * Return the combined camera matrix for visibility
 * testing against the camera viewing frustum.
 ***********************************************************/
glm::mat4 ViewManager::GetViewProjectionMatrix() const
{
    return m_projectionMatrix * m_viewMatrix;
}
