
///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// Manage the loading and rendering of 3D scenes.
//
// Original author: Brian Battersby - SNHU Instructor
// CS-330 Computational Graphics and Visualization, Nov. 1, 2023
//
// CS-499 Enhancement Two: Algorithms and Data Structures
// Added scene-object organization, bounding-sphere frustum
// culling, and rendering statistics.
//
// Original scene geometry, transforms, materials, textures,
// and lighting values are preserved.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

#include <algorithm>
#include <cmath>
#include <iostream>

// Shader variable names
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 * Constructor
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    // Initialize the original texture counter.
    m_loadedTextures = 0;
}

/***********************************************************
 * Destructor
 ***********************************************************/
SceneManager::~SceneManager()
{
    // Release textures while the OpenGL context is active.
    DestroyGLTextures();

    delete m_basicMeshes;
    m_basicMeshes = nullptr;
    m_pShaderManager = nullptr;
}

/***********************************************************
 * CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(
    const char* filename,
    std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // Preserve the original 16-slot storage limit.
    if (m_loadedTextures >= 16)
    {
        std::cerr << "Texture storage is full."
                  << std::endl;
        return false;
    }

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(
        filename,
        &width,
        &height,
        &colorChannels,
        0);

    if (image)
    {
        std::cout
            << "Successfully loaded image: "
            << filename
            << ", width: " << width
            << ", height: " << height
            << ", channels: " << colorChannels
            << std::endl;

        // Reject unsupported formats before creating
        // an OpenGL texture.
        if (colorChannels != 3 && colorChannels != 4)
        {
            std::cerr
                << "Unsupported image channels: "
                << colorChannels
                << std::endl;

            stbi_image_free(image);
            return false;
        }

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_WRAP_S,
            GL_REPEAT);

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_WRAP_T,
            GL_REPEAT);

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_MIN_FILTER,
            GL_LINEAR);

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_MAG_FILTER,
            GL_LINEAR);

        if (colorChannels == 3)
        {
            glTexImage2D(
                GL_TEXTURE_2D,
                0,
                GL_RGB8,
                width,
                height,
                0,
                GL_RGB,
                GL_UNSIGNED_BYTE,
                image);
        }
        else
        {
            glTexImage2D(
                GL_TEXTURE_2D,
                0,
                GL_RGBA8,
                width,
                height,
                0,
                GL_RGBA,
                GL_UNSIGNED_BYTE,
                image);
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        ++m_loadedTextures;

        return true;
    }

    std::cerr
        << "Could not load image: "
        << filename
        << std::endl;

    return false;
}

/***********************************************************
 * BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(
            GL_TEXTURE_2D,
            m_textureIDs[i].ID);
    }
}

/***********************************************************
 * DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glDeleteTextures(
            1,
            &m_textureIDs[i].ID);
    }

    m_loadedTextures = 0;
}

/***********************************************************
 * FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        if (m_textureIDs[i].tag == tag)
        {
            return static_cast<int>(
                m_textureIDs[i].ID);
        }
    }

    return -1;
}

/***********************************************************
 * FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        if (m_textureIDs[i].tag == tag)
        {
            return i;
        }
    }

    return -1;
}

/***********************************************************
 * FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(
    std::string tag,
    OBJECT_MATERIAL& material)
{
    for (const auto& candidate : m_objectMaterials)
    {
        if (candidate.tag == tag)
        {
            material = candidate;
            return true;
        }
    }

    return false;
}

/***********************************************************
 * CS-499 ENHANCEMENT:
 * RegisterSceneObject()
 *
 * Store a named scene object with a bounding sphere.
 ***********************************************************/
void SceneManager::RegisterSceneObject(
    const std::string& name,
    const glm::vec3& center,
    float boundingRadius)
{
    if (boundingRadius < 0.0f)
    {
        std::cerr
            << "Invalid bounding radius for: "
            << name
            << std::endl;
        return;
    }

    for (auto& object : m_sceneObjects)
    {
        if (object.name == name)
        {
            object.center = center;
            object.boundingRadius = boundingRadius;
            return;
        }
    }

    SceneObject object;
    object.name = name;
    object.center = center;
    object.boundingRadius = boundingRadius;

    m_sceneObjects.push_back(object);
}

/***********************************************************
 * CS-499 ENHANCEMENT:
 * UpdateFrustum()
 *
 * Extract six frustum planes from the combined
 * projection * view matrix.
 *
 * GLM matrices are column-major. We construct
 * mathematical rows before extracting planes.
 ***********************************************************/
void SceneManager::UpdateFrustum(
    const glm::mat4& viewProjection)
{
    glm::vec4 row0(
        viewProjection[0][0],
        viewProjection[1][0],
        viewProjection[2][0],
        viewProjection[3][0]);

    glm::vec4 row1(
        viewProjection[0][1],
        viewProjection[1][1],
        viewProjection[2][1],
        viewProjection[3][1]);

    glm::vec4 row2(
        viewProjection[0][2],
        viewProjection[1][2],
        viewProjection[2][2],
        viewProjection[3][2]);

    glm::vec4 row3(
        viewProjection[0][3],
        viewProjection[1][3],
        viewProjection[2][3],
        viewProjection[3][3]);

    // Left, right, bottom, top, near, far.
    std::array<glm::vec4, 6> rawPlanes =
    {
        row3 + row0,
        row3 - row0,
        row3 + row1,
        row3 - row1,
        row3 + row2,
        row3 - row2
    };

    for (size_t i = 0; i < rawPlanes.size(); ++i)
    {
        glm::vec3 normal(rawPlanes[i]);

        float length = glm::length(normal);

        if (length > 0.000001f)
        {
            m_frustumPlanes[i].normal =
                normal / length;

            m_frustumPlanes[i].distance =
                rawPlanes[i].w / length;
        }
        else
        {
            // Degenerate plane: avoid incorrectly
            // culling objects.
            m_frustumPlanes[i].normal =
                glm::vec3(0.0f);

            m_frustumPlanes[i].distance = 0.0f;
        }
    }
}

/***********************************************************
 * CS-499 ENHANCEMENT:
 * IsObjectVisible()
 *
 * A sphere is outside the frustum if its signed
 * distance to any plane is less than -radius.
 *
 * Time complexity: O(6), or O(1) per object.
 ***********************************************************/
bool SceneManager::IsObjectVisible(
    const SceneObject& object) const
{
    for (const auto& plane : m_frustumPlanes)
    {
        float signedDistance =
            glm::dot(plane.normal, object.center)
            + plane.distance;

        if (signedDistance < -object.boundingRadius)
        {
            return false;
        }
    }

    return true;
}

/***********************************************************
 * CS-499 ENHANCEMENT:
 * ShouldRenderObject()
 *
 * Find the registered object and determine whether
 * its bounding sphere intersects the camera frustum.
 ***********************************************************/
bool SceneManager::ShouldRenderObject(
    const std::string& name)
{
    ++m_objectsTested;

    for (const auto& object : m_sceneObjects)
    {
        if (object.name == name)
        {
            if (IsObjectVisible(object))
            {
                ++m_objectsRendered;
                return true;
            }

            ++m_objectsCulled;
            return false;
        }
    }

    // Missing registration: render conservatively.
    std::cerr
        << "Unregistered scene object: "
        << name
        << std::endl;

    ++m_objectsRendered;
    return true;
}

/***********************************************************
 * CS-499 ENHANCEMENT:
 * BeginFrame()
 *
 * Reset statistics and update the camera frustum.
 ***********************************************************/
void SceneManager::BeginFrame(
    const glm::mat4& viewProjection)
{
    m_objectsTested = 0;
    m_objectsRendered = 0;
    m_objectsCulled = 0;

    UpdateFrustum(viewProjection);
}

/***********************************************************
 * CS-499 ENHANCEMENT:
 * Rendering statistics
 ***********************************************************/
int SceneManager::GetObjectsTested() const
{
    return m_objectsTested;
}

int SceneManager::GetObjectsRendered() const
{
    return m_objectsRendered;
}

int SceneManager::GetObjectsCulled() const
{
    return m_objectsCulled;
}

/***********************************************************
 * SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale =
        glm::scale(scaleXYZ);

    glm::mat4 rotationX =
        glm::rotate(
            glm::radians(XrotationDegrees),
            glm::vec3(1.0f, 0.0f, 0.0f));

    glm::mat4 rotationY =
        glm::rotate(
            glm::radians(YrotationDegrees),
            glm::vec3(0.0f, 1.0f, 0.0f));

    glm::mat4 rotationZ =
        glm::rotate(
            glm::radians(ZrotationDegrees),
            glm::vec3(0.0f, 0.0f, 1.0f));

    glm::mat4 translation =
        glm::translate(positionXYZ);

    glm::mat4 modelView =
        translation
        * rotationX
        * rotationY
        * rotationZ
        * scale;

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(
            g_ModelName,
            modelView);
    }
}

/***********************************************************
 * SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(
        redColorValue,
        greenColorValue,
        blueColorValue,
        alphaValue);

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setIntValue(
            g_UseTextureName,
            false);

        m_pShaderManager->setVec4Value(
            g_ColorValueName,
            currentColor);
    }
}

/***********************************************************
 * SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (m_pShaderManager == nullptr)
    {
        return;
    }

    int textureSlot =
        FindTextureSlot(textureTag);

    if (textureSlot < 0)
    {
        m_pShaderManager->setIntValue(
            g_UseTextureName,
            false);
        return;
    }

    m_pShaderManager->setIntValue(
        g_UseTextureName,
        true);

    m_pShaderManager->setSampler2DValue(
        g_TextureValueName,
        textureSlot);
}

/***********************************************************
 * SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(
    float u,
    float v)
{
    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setVec2Value(
            "UVscale",
            glm::vec2(u, v));
    }
}

/***********************************************************
 * SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_pShaderManager == nullptr)
    {
        return;
    }

    OBJECT_MATERIAL material;

    if (FindMaterial(materialTag, material))
    {
        m_pShaderManager->setVec3Value(
            "material.ambientColor",
            material.ambientColor);

        m_pShaderManager->setFloatValue(
            "material.ambientStrength",
            material.ambientStrength);

        m_pShaderManager->setVec3Value(
            "material.diffuseColor",
            material.diffuseColor);

        m_pShaderManager->setVec3Value(
            "material.specularColor",
            material.specularColor);

        m_pShaderManager->setFloatValue(
            "material.shininess",
            material.shininess);
    }
}

/***********************************************************
 * DefineObjectMaterials()
 *
 * Original material definitions preserved.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    OBJECT_MATERIAL mugMaterial;

    mugMaterial.ambientColor =
        glm::vec3(0.10f, 0.18f, 0.35f);

    mugMaterial.ambientStrength = 0.30f;

    mugMaterial.diffuseColor =
        glm::vec3(0.15f, 0.35f, 0.75f);

    mugMaterial.specularColor =
        glm::vec3(0.65f, 0.65f, 0.65f);

    mugMaterial.shininess = 48.0f;
    mugMaterial.tag = "mug";

    m_objectMaterials.push_back(mugMaterial);

    OBJECT_MATERIAL planeMaterial;

    planeMaterial.ambientColor =
        glm::vec3(0.20f, 0.20f, 0.20f);

    planeMaterial.ambientStrength = 0.35f;

    planeMaterial.diffuseColor =
        glm::vec3(0.55f, 0.55f, 0.55f);

    planeMaterial.specularColor =
        glm::vec3(0.20f, 0.20f, 0.20f);

    planeMaterial.shininess = 16.0f;
    planeMaterial.tag = "plane";

    m_objectMaterials.push_back(planeMaterial);
}

/***********************************************************
 * SetupSceneLights()
 *
 * Original lighting values preserved.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    m_pShaderManager->setBoolValue(
        g_UseLightingName,
        true);

    // Main white light
    m_pShaderManager->setVec3Value(
        "lightSources[0].position",
        -4.0f, 8.0f, 8.0f);

    m_pShaderManager->setVec3Value(
        "lightSources[0].ambientColor",
        0.70f, 0.70f, 0.70f);

    m_pShaderManager->setVec3Value(
        "lightSources[0].diffuseColor",
        0.45f, 0.45f, 0.45f);

    m_pShaderManager->setVec3Value(
        "lightSources[0].specularColor",
        0.25f, 0.25f, 0.25f);

    m_pShaderManager->setFloatValue(
        "lightSources[0].focalStrength",
        32.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[0].specularIntensity",
        0.25f);

    // Secondary warm light
    m_pShaderManager->setVec3Value(
        "lightSources[1].position",
        5.0f, 5.0f, 6.0f);

    m_pShaderManager->setVec3Value(
        "lightSources[1].ambientColor",
        0.15f, 0.08f, 0.04f);

    m_pShaderManager->setVec3Value(
        "lightSources[1].diffuseColor",
        0.30f, 0.12f, 0.05f);

    m_pShaderManager->setVec3Value(
        "lightSources[1].specularColor",
        0.20f, 0.10f, 0.05f);

    m_pShaderManager->setFloatValue(
        "lightSources[1].focalStrength",
        32.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[1].specularIntensity",
        0.20f);
}

/***********************************************************
 * PrepareScene()
 *
 * Original scene resources preserved.
 * CS-499: Register bounding spheres for the three
 * existing renderable scene objects.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    SetupSceneLights();

    CreateGLTexture(
        "Utilities/textures/rusticwood.jpg",
        "wood");

    CreateGLTexture(
        "Utilities/textures/stainless.jpg",
        "mugTexture");

    BindGLTextures();

    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTorusMesh();

    // CS-499 ENHANCEMENT:
    // Conservative world-space bounding spheres.
    // These are deliberately larger than the geometry
    // to reduce the risk of incorrect culling.

    m_sceneObjects.clear();

    // Ground plane: scaled to 20 x 10 in X/Z.
    RegisterSceneObject(
        "ground",
        glm::vec3(0.0f, 0.0f, 0.0f),
        25.0f);

    // Mug body: original center and dimensions.
    RegisterSceneObject(
        "mugBody",
        glm::vec3(0.0f, 3.0f, 0.0f),
        6.0f);

    // Mug handle: original position and rotation.
    RegisterSceneObject(
        "mugHandle",
        glm::vec3(2.30f, 3.30f, 0.0f),
        4.0f);
}

/***********************************************************
 * RenderScene()
 *
 * Original scene preserved.
 * CS-499: Each draw section is now conditional on
 * the corresponding object's visibility.
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /********************************************************
     * GROUND PLANE
     ********************************************************/
    if (ShouldRenderObject("ground"))
    {
        scaleXYZ =
            glm::vec3(20.0f, 1.0f, 10.0f);

        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 0.0f;

        positionXYZ =
            glm::vec3(0.0f, 0.0f, 0.0f);

        SetTransformations(
            scaleXYZ,
            XrotationDegrees,
            YrotationDegrees,
            ZrotationDegrees,
            positionXYZ);

        SetShaderColor(1, 1, 1, 1);

        m_pShaderManager->setVec3Value(
            "material.ambientColor",
            0.60f, 0.60f, 0.60f);

        m_pShaderManager->setFloatValue(
            "material.ambientStrength",
            0.25f);

        m_pShaderManager->setVec3Value(
            "material.diffuseColor",
            0.70f, 0.70f, 0.70f);

        m_pShaderManager->setVec3Value(
            "material.specularColor",
            0.35f, 0.35f, 0.35f);

        m_pShaderManager->setFloatValue(
            "material.shininess",
            24.0f);

        SetShaderTexture("wood");
        SetTextureUVScale(4.0f, 4.0f);

        m_basicMeshes->DrawPlaneMesh();
    }

    /********************************************************
     * MUG BODY
     ********************************************************/
    if (ShouldRenderObject("mugBody"))
    {
        scaleXYZ =
            glm::vec3(2.0f, 3.0f, 2.0f);

        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 0.0f;

        positionXYZ =
            glm::vec3(0.0f, 3.0f, 0.0f);

        SetTransformations(
            scaleXYZ,
            XrotationDegrees,
            YrotationDegrees,
            ZrotationDegrees,
            positionXYZ);

        SetShaderColor(
            0.15f, 0.35f, 0.75f, 1.0f);

        m_pShaderManager->setVec3Value(
            "material.ambientColor",
            0.15f, 0.35f, 0.75f);

        m_pShaderManager->setFloatValue(
            "material.ambientStrength",
            0.40f);

        m_pShaderManager->setVec3Value(
            "material.diffuseColor",
            0.15f, 0.35f, 0.75f);

        m_pShaderManager->setVec3Value(
            "material.specularColor",
            0.50f, 0.50f, 0.50f);

        m_pShaderManager->setFloatValue(
            "material.shininess",
            32.0f);

        SetShaderTexture("mugTexture");
        SetTextureUVScale(2.0f, 2.0f);

        m_basicMeshes->DrawCylinderMesh(
            true, true, true);
    }

    /********************************************************
     * MUG HANDLE
     ********************************************************/
    if (ShouldRenderObject("mugHandle"))
    {
        scaleXYZ =
            glm::vec3(1.15f, 1.15f, 1.15f);

        XrotationDegrees = 0.0f;
        YrotationDegrees = 90.0f;
        ZrotationDegrees = 0.0f;

        positionXYZ =
            glm::vec3(2.30f, 3.30f, 0.0f);

        SetTransformations(
            scaleXYZ,
            XrotationDegrees,
            YrotationDegrees,
            ZrotationDegrees,
            positionXYZ);

        SetShaderColor(
            0.15f, 0.35f, 0.75f, 1.0f);

        m_pShaderManager->setVec3Value(
            "material.ambientColor",
            0.1f, 1.0f, 1.0f);

        m_pShaderManager->setFloatValue(
            "material.ambientStrength",
            0.30f);

        m_pShaderManager->setVec3Value(
            "material.diffuseColor",
            1.0f, 1.0f, 1.0f);

        m_pShaderManager->setVec3Value(
            "material.specularColor",
            1.0f, 1.0f, 1.0f);

        m_pShaderManager->setFloatValue(
            "material.shininess",
            32.0f);

        SetShaderTexture("mugTexture");
        SetTextureUVScale(2.0f, 2.0f);

        m_basicMeshes->DrawHalfTorusMesh();
    }
}
