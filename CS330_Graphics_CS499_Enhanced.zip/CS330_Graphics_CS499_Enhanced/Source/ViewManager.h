
///////////////////////////////////////////////////////////////////////////////
// ViewManager.h
// ============
// Manage the viewing of 3D objects within the viewport.
//
// Original author: Brian Battersby - SNHU Instructor
// CS-330 Computational Graphics and Visualization, November 1, 2023
//
// CS-499 Enhancement Two: Algorithms and Data Structures
// Added camera matrix access to support frustum culling.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h"

// GLM mathematics library
#include <glm/glm.hpp>

class ViewManager
{
public:
    // Constructor
    ViewManager(ShaderManager* pShaderManager);

    // Destructor
    ~ViewManager();

    // Mouse position callback for camera interaction
    static void Mouse_Position_Callback(
        GLFWwindow* window,
        double xMousePos,
        double yMousePos);

    // Mouse scroll callback for camera zoom
    static void Mouse_Scroll_Callback(
        GLFWwindow* window,
        double xOffset,
        double yOffset);

private:
    // Pointer to shader manager object
    ShaderManager* m_pShaderManager;

    // Active OpenGL display window
    GLFWwindow* m_pWindow;

    // CS-499 ENHANCEMENT:
    // Store the current view and projection matrices.
    // These will support visibility testing and frustum culling.
    glm::mat4 m_viewMatrix{1.0f};
    glm::mat4 m_projectionMatrix{1.0f};

    // Process keyboard events for camera movement
    void ProcessKeyboardEvents();

public:
    // Create the initial OpenGL display window
    GLFWwindow* CreateDisplayWindow(
        const char* windowTitle);

    // Prepare the conversion from 3D to 2D scene display
    void PrepareSceneView();

    // CS-499 ENHANCEMENT:
    // Return the combined view-projection matrix.
    // SceneManager will use this matrix to determine
    // which scene objects are potentially visible.
    glm::mat4 GetViewProjectionMatrix() const;
};
