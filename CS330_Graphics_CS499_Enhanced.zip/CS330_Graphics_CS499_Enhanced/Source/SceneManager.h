
///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ============
// Manage the loading and rendering of 3D scenes.
//
// Original author: Brian Battersby - SNHU Instructor
// CS-330 Computational Graphics and Visualization, November 1, 2023
//
// CS-499 Enhancement Two: Algorithms and Data Structures
// Added scene-object storage and frustum-culling interfaces.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <glm/glm.hpp>

#include <array>
#include <cstdint>
#include <string>
#include <vector>

class SceneManager
{
public:
    // Constructor and destructor
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    struct OBJECT_MATERIAL
    {
        float ambientStrength;
        glm::vec3 ambientColor;
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

    // CS-499 ENHANCEMENT:
    // Represents a renderable object and its bounding sphere.
    struct SceneObject
    {
        std::string name;
        glm::vec3 center;
        float boundingRadius;
    };

    // CS-499 ENHANCEMENT:
    // Represents a normalized plane in the viewing frustum.
    struct FrustumPlane
    {
        glm::vec3 normal;
        float distance;
    };

private:
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_basicMeshes;

    // Original texture and material storage
    int m_loadedTextures;
    TEXTURE_INFO m_textureIDs[16];
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // CS-499 ENHANCEMENT:
    // Dynamic collection of objects used for visibility testing.
    std::vector<SceneObject> m_sceneObjects;

    // Six frustum planes: left, right, bottom, top, near, far.
    std::array<FrustumPlane, 6> m_frustumPlanes{};

    // Rendering statistics for the current frame.
    int m_objectsTested = 0;
    int m_objectsRendered = 0;
    int m_objectsCulled = 0;

    // Existing texture management methods
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();

    int FindTextureID(std::string tag);
    int FindTextureSlot(std::string tag);

    // Existing material lookup
    bool FindMaterial(
        std::string tag,
        OBJECT_MATERIAL& material);

    // CS-499 ENHANCEMENT:
    // Register a scene object and its bounding sphere.
    void RegisterSceneObject(
        const std::string& name,
        const glm::vec3& center,
        float boundingRadius);

    // Extract six normalized frustum planes from the
    // camera's combined view-projection matrix.
    void UpdateFrustum(const glm::mat4& viewProjection);

    // Test whether a bounding sphere intersects
    // the camera's viewing frustum.
    bool IsObjectVisible(const SceneObject& object) const;

    // Locate a registered object and test its visibility.
    bool ShouldRenderObject(const std::string& name);

    // Existing transformation and shader methods
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

    void SetShaderTexture(std::string textureTag);

    void SetTextureUVScale(float u, float v);

    void SetShaderMaterial(std::string materialTag);

public:
    // Existing scene methods
    void DefineObjectMaterials();
    void PrepareScene();
    void SetupSceneLights();

    // CS-499 ENHANCEMENT:
    // Update visibility information before rendering.
    void BeginFrame(const glm::mat4& viewProjection);

    // Render visible scene objects.
    void RenderScene();

    // Access frame statistics for performance evaluation.
    int GetObjectsTested() const;
    int GetObjectsRendered() const;
    int GetObjectsCulled() const;
};
