
///////////////////////////////////////////////////////////////////////////////
// MainCode.cpp
// CS-330 Original Graphics Project
// CS-499 Enhancement Two: Algorithms and Data Structures
//
// Preserves the original 3D graphics application.
// Adds camera-frustum culling and performance diagnostics.
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Global application objects
namespace
{
    const char* const WINDOW_TITLE =
        "CS-499 Enhanced 3D Graphics - Frustum Culling";

    GLFWwindow* g_Window = nullptr;

    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

// Function declarations
bool InitializeGLFW();
bool InitializeGLEW();

/***********************************************************
 * main()
 ***********************************************************/
int main(int argc, char* argv[])
{
    if (InitializeGLFW() == false)
    {
        return EXIT_FAILURE;
    }

    g_ShaderManager = new ShaderManager();

    g_ViewManager = new ViewManager(
        g_ShaderManager);

    g_Window = g_ViewManager->CreateDisplayWindow(
        WINDOW_TITLE);

    if (g_Window == nullptr)
    {
        delete g_ViewManager;
        delete g_ShaderManager;
        glfwTerminate();
        return EXIT_FAILURE;
    }

    if (InitializeGLEW() == false)
    {
        delete g_ViewManager;
        delete g_ShaderManager;
        glfwDestroyWindow(g_Window);
        glfwTerminate();
        return EXIT_FAILURE;
    }

    // Load shaders from the enhanced project directory.
    g_ShaderManager->LoadShaders(
        "Utilities/shaders/vertexShader.glsl",
        "Utilities/shaders/fragmentShader.glsl");

    g_ShaderManager->use();

    // Prepare the original 3D scene.
    g_SceneManager = new SceneManager(
        g_ShaderManager);

    g_SceneManager->PrepareScene();

    // Diagnostic timing.
    double lastDiagnosticTime = -1.0;

    /********************************************************
     * Main Rendering Loop
     ********************************************************/
    while (!glfwWindowShouldClose(g_Window))
    {
        glEnable(GL_DEPTH_TEST);

        glClearColor(
            0.0f, 0.0f, 0.0f, 1.0f);

        glClear(
            GL_COLOR_BUFFER_BIT |
            GL_DEPTH_BUFFER_BIT);

        // Update camera view and projection.
        g_ViewManager->PrepareSceneView();

        // CS-499 ENHANCEMENT TWO:
        // Recalculate the camera frustum each frame.
        g_SceneManager->BeginFrame(
            g_ViewManager->GetViewProjectionMatrix());

        // Test visibility and render eligible objects.
        g_SceneManager->RenderScene();

        /****************************************************
         * CS-499 FRUSTUM-CULLING DIAGNOSTIC
         *
         * Display rendering statistics once per second.
         ****************************************************/
        double currentTime = glfwGetTime();

        if (lastDiagnosticTime < 0.0 ||
            currentTime - lastDiagnosticTime >= 1.0)
        {
            std::cout
                << "[CS-499 Frustum Culling] "
                << "Tested: "
                << g_SceneManager->GetObjectsTested()
                << " | Rendered: "
                << g_SceneManager->GetObjectsRendered()
                << " | Culled: "
                << g_SceneManager->GetObjectsCulled()
                << std::endl;

            lastDiagnosticTime = currentTime;
        }

        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    /********************************************************
     * Application Cleanup
     ********************************************************/
    if (g_SceneManager != nullptr)
    {
        delete g_SceneManager;
        g_SceneManager = nullptr;
    }

    if (g_ViewManager != nullptr)
    {
        delete g_ViewManager;
        g_ViewManager = nullptr;
    }

    if (g_ShaderManager != nullptr)
    {
        delete g_ShaderManager;
        g_ShaderManager = nullptr;
    }

    glfwDestroyWindow(g_Window);
    glfwTerminate();

    return EXIT_SUCCESS;
}

/***********************************************************
 * InitializeGLFW()
 ***********************************************************/
bool InitializeGLFW()
{
    if (glfwInit() == GLFW_FALSE)
    {
        std::cerr
            << "Failed to initialize GLFW."
            << std::endl;
        return false;
    }

#ifdef __APPLE__
    glfwWindowHint(
        GLFW_CONTEXT_VERSION_MAJOR, 3);

    glfwWindowHint(
        GLFW_CONTEXT_VERSION_MINOR, 3);

    glfwWindowHint(
        GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

    glfwWindowHint(
        GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#else
    glfwWindowHint(
        GLFW_CONTEXT_VERSION_MAJOR, 4);

    glfwWindowHint(
        GLFW_CONTEXT_VERSION_MINOR, 6);

    glfwWindowHint(
        GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

    return true;
}

/***********************************************************
 * InitializeGLEW()
 ***********************************************************/
bool InitializeGLEW()
{
    GLenum GLEWInitResult = glewInit();

    if (GLEWInitResult != GLEW_OK)
    {
        std::cerr
            << glewGetErrorString(GLEWInitResult)
            << std::endl;
        return false;
    }

    std::cout
        << "INFO: OpenGL Successfully Initialized\n";

    std::cout
        << "INFO: OpenGL Version: "
        << glGetString(GL_VERSION)
        << "\n"
        << std::endl;

    return true;
}
