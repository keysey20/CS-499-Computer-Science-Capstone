
cmake_minimum_required(VERSION 3.16)

project(CS499_Graphics_Enhanced LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(OpenGL REQUIRED)
find_package(glfw3 CONFIG REQUIRED)
find_package(GLEW REQUIRED)
find_package(glm CONFIG REQUIRED)

add_executable(CS499_Graphics_Enhanced
    Source/MainCode.cpp
    Source/SceneManager.cpp
    Source/ViewManager.cpp
    3DShapes/ShapeMeshes.cpp
    Utilities/ShaderManager.cpp
)

target_include_directories(CS499_Graphics_Enhanced PRIVATE
    Source
    3DShapes
    Utilities
)

# Enable GLM experimental extensions
target_compile_definitions(CS499_Graphics_Enhanced PRIVATE
    GLM_ENABLE_EXPERIMENTAL
)

target_link_libraries(CS499_Graphics_Enhanced PRIVATE
    OpenGL::GL
    glfw
    GLEW::GLEW
    glm::glm
)

if(APPLE)
    target_compile_definitions(CS499_Graphics_Enhanced PRIVATE
        GL_SILENCE_DEPRECATION
    )
endif()
