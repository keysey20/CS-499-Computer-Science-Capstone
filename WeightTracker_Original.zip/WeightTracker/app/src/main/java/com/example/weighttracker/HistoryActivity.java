
package com.example.weighttracker;

import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {

    private LinearLayout historyContainer;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        historyContainer = findViewById(R.id.historyContainer);
        databaseHelper = new DatabaseHelper(this);

        Button addWeightButton = findViewById(R.id.buttonAddWeight);
        Button backButton = findViewById(R.id.buttonBack);

        addWeightButton.setOnClickListener(v -> finish());
        backButton.setOnClickListener(v -> finish());

        loadWeights();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (databaseHelper != null) {
            loadWeights();
        }
    }

    private void loadWeights() {
        historyContainer.removeAllViews();
        createHeader();

        try (Cursor cursor = databaseHelper.getAllWeights()) {
            if (!cursor.moveToFirst()) {
                showEmptyMessage();
                return;
            }

            int idIndex = cursor.getColumnIndexOrThrow("id");
            int weightIndex = cursor.getColumnIndexOrThrow("weight");
            int dateIndex = cursor.getColumnIndexOrThrow("date");

            do {
                int id = cursor.getInt(idIndex);
                String weight = cursor.getString(weightIndex);
                String date = cursor.getString(dateIndex);

                createWeightRow(id, weight, date);
            } while (cursor.moveToNext());

        } catch (Exception e) {
            Toast.makeText(this,
                    "Unable to load weight history",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void createHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(8, 12, 8, 12);

        header.addView(createHeaderText("DATE / WEIGHT", 2f));
        header.addView(createHeaderText("ACTIONS", 1f));

        historyContainer.addView(header);
    }

    private TextView createHeaderText(String text, float weight) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(16);
        view.setTypeface(null, android.graphics.Typeface.BOLD);
        view.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        return view;
    }

    private void showEmptyMessage() {
        TextView emptyText = new TextView(this);
        emptyText.setText("No weight entries yet.");
        emptyText.setTextSize(18);
        emptyText.setPadding(16, 16, 16, 16);
        historyContainer.addView(emptyText);
    }

    private void createWeightRow(int id, String weight, String date) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(8, 12, 8, 12);

        TextView weightText = new TextView(this);
        weightText.setText(date + "\n" + weight + " lbs");
        weightText.setTextSize(16);
        weightText.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button editButton = new Button(this);
        editButton.setText("Edit");
        editButton.setOnClickListener(v ->
                showEditDialog(id, weight, date));

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(v ->
                confirmDeletion(id));

        row.addView(weightText);
        row.addView(editButton);
        row.addView(deleteButton);

        historyContainer.addView(row);
    }

    private void showEditDialog(int id, String weight, String date) {
        EditText weightInput = new EditText(this);
        weightInput.setText(weight);
        weightInput.setHint("Weight in pounds");
        weightInput.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL);

        EditText dateInput = new EditText(this);
        dateInput.setText(date);
        dateInput.setHint("MM/dd/yyyy");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        layout.addView(weightInput);
        layout.addView(dateInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit Weight Entry")
                .setView(layout)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(ignored ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(v -> {
                            String newWeight = weightInput.getText()
                                    .toString().trim();
                            String newDate = dateInput.getText()
                                    .toString().trim();

                            if (!isValidWeight(newWeight)) {
                                weightInput.setError(
                                        "Enter a positive, valid weight");
                                return;
                            }

                            if (!isValidDate(newDate)) {
                                dateInput.setError(
                                        "Use a valid date: MM/dd/yyyy");
                                return;
                            }

                            try {
                                boolean updated = databaseHelper.updateWeight(
                                        id, newWeight, newDate);

                                if (updated) {
                                    dialog.dismiss();
                                    loadWeights();
                                    Toast.makeText(this,
                                            "Weight updated successfully",
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(this,
                                            "Unable to update weight",
                                            Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                Toast.makeText(this,
                                        "Error updating weight",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }));

        dialog.show();
    }

    private boolean isValidWeight(String value) {
        try {
            double weight = Double.parseDouble(value);
            return Double.isFinite(weight) && weight > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isValidDate(String value) {
        SimpleDateFormat format =
                new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        format.setLenient(false);

        ParsePosition position = new ParsePosition(0);
        return format.parse(value, position) != null
                && position.getIndex() == value.length();
    }

    private void confirmDeletion(int id) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Weight Entry?")
                .setMessage("This action cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    try {
                        boolean deleted = databaseHelper.deleteWeight(id);

                        if (deleted) {
                            loadWeights();
                            Toast.makeText(this,
                                    "Weight entry deleted",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this,
                                    "Unable to delete entry",
                                    Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this,
                                "Error deleting entry",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        super.onDestroy();
    }
}
