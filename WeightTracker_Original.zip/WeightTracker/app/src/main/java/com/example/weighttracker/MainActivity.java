
package com.example.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "WeightTrackerPrefs";
    private static final int SMS_PERMISSION_REQUEST = 100;

    private DatabaseHelper databaseHelper;

    private TextView currentWeightText;
    private TextView goalWeightText;
    private ProgressBar weightProgress;
    private TextView progressPercentText;

    private EditText weightInput;
    private EditText phoneInput;
    private EditText goalWeightInput;

    private boolean dashboardVisible = false;
    private boolean goalNotificationSent = false;
    private String pendingPhoneNumber;
    private String pendingGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        databaseHelper = new DatabaseHelper(this);

        showLoginScreen();

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(android.R.id.content),
                (view, insets) -> {
                    Insets bars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());
                    view.setPadding(
                            bars.left, bars.top,
                            bars.right, bars.bottom);
                    return insets;
                });
    }

    private void showLoginScreen() {
        dashboardVisible = false;
        setContentView(R.layout.activity_login);

        EditText usernameInput = findViewById(R.id.editUsername);
        EditText passwordInput = findViewById(R.id.editPassword);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton =
                findViewById(R.id.buttonCreateAccount);

        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText()
                    .toString().trim();
            String password = passwordInput.getText()
                    .toString();

            loginUser(username, password);
        });

        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText()
                    .toString().trim();
            String password = passwordInput.getText()
                    .toString();

            registerUser(username, password);
        });
    }

    private void loginUser(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            showMessage("Please enter your username and password");
            return;
        }

        try {
            if (databaseHelper.checkUser(username, password)) {
                showMessage("Login successful");
                showDashboard();
            } else {
                showMessage("Incorrect username or password");
            }
        } catch (Exception e) {
            showMessage("Unable to log in. Please try again.");
        }
    }

    private void registerUser(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            showMessage("Please enter a username and password");
            return;
        }

        if (username.length() < 3) {
            showMessage("Username must have at least 3 characters");
            return;
        }

        if (password.length() < 8) {
            showMessage("Password must have at least 8 characters");
            return;
        }

        try {
            if (databaseHelper.registerUser(username, password)) {
                showMessage("Account created successfully");
            } else {
                showMessage("Username already exists");
            }
        } catch (Exception e) {
            showMessage("Unable to create account");
        }
    }

    private void showDashboard() {
        setContentView(R.layout.activity_main);
        dashboardVisible = true;

        currentWeightText = findViewById(R.id.textCurrentWeight);
        goalWeightText = findViewById(R.id.textGoalWeight);
        weightProgress = findViewById(R.id.progressWeight);
        progressPercentText =
                findViewById(R.id.textProgressPercent);

        weightInput = findViewById(R.id.weightInput);
        phoneInput = findViewById(R.id.editPhoneNumber);
        goalWeightInput = findViewById(R.id.editGoalWeight);

        Button saveWeightButton =
                findViewById(R.id.saveWeightButton);
        Button historyButton =
                findViewById(R.id.viewHistoryButton);

        SharedPreferences preferences =
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        String savedPhone =
                preferences.getString("phoneNumber", "");
        String savedGoal =
                preferences.getString("goalWeight", "");

        phoneInput.setText(savedPhone);
        goalWeightInput.setText(savedGoal);

        saveWeightButton.setOnClickListener(v -> saveWeight());

        historyButton.setOnClickListener(v ->
                startActivity(new Intent(
                        MainActivity.this,
                        HistoryActivity.class)));

        refreshDashboard();
    }

    private void saveWeight() {
        String weight = weightInput.getText()
                .toString().trim();
        String goal = goalWeightInput.getText()
                .toString().trim();
        String phone = phoneInput.getText()
                .toString().trim();

        if (!isValidWeight(weight)) {
            weightInput.setError("Enter a positive, valid weight");
            return;
        }

        if (!goal.isEmpty() && !isValidWeight(goal)) {
            goalWeightInput.setError("Enter a valid goal weight");
            return;
        }

        if (!phone.isEmpty() &&
                !android.util.Patterns.PHONE.matcher(phone).matches()) {
            phoneInput.setError("Enter a valid phone number");
            return;
        }

        String date = new SimpleDateFormat(
                "MM/dd/yyyy", Locale.US).format(new Date());

        try {
            boolean inserted = databaseHelper.addWeight(weight, date);

            if (!inserted) {
                showMessage("Unable to save weight");
                return;
            }

            getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                    .edit()
                    .putString("phoneNumber", phone)
                    .putString("goalWeight", goal)
                    .apply();

            weightInput.setText("");
            showMessage("Weight saved: " + weight + " lbs");

            refreshDashboard();

            if (!goal.isEmpty() && !phone.isEmpty()) {
                double current = Double.parseDouble(weight);
                double target = Double.parseDouble(goal);

                if (current <= target && !goalNotificationSent) {
                    sendGoalNotification(phone, goal);
                }
            }

        } catch (Exception e) {
            showMessage("An error occurred while saving weight");
        }
    }

    private boolean isValidWeight(String value) {
        try {
            double weight = Double.parseDouble(value);
            return Double.isFinite(weight) && weight > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void refreshDashboard() {
        if (!dashboardVisible) {
            return;
        }

        String latestWeight = "";
        String startingWeight = "";

        try (Cursor cursor = databaseHelper.getAllWeights()) {
            if (cursor.moveToFirst()) {
                latestWeight = cursor.getString(
                        cursor.getColumnIndexOrThrow("weight"));
            }
        } catch (Exception e) {
            showMessage("Unable to refresh weight information");
            return;
        }

        try (Cursor cursor = databaseHelper.getStartingWeight()) {
            if (cursor.moveToFirst()) {
                startingWeight = cursor.getString(
                        cursor.getColumnIndexOrThrow("weight"));
            }
        } catch (Exception e) {
            showMessage("Unable to load starting weight");
        }

        currentWeightText.setText(
                latestWeight.isEmpty() ? "No entries" :
                        latestWeight + " lbs");

        String goal = getSharedPreferences(
                PREFS_NAME, MODE_PRIVATE)
                .getString("goalWeight", "");

        goalWeightText.setText(
                goal.isEmpty() ? "Not set" : goal + " lbs");

        weightProgress.setProgress(0);
        progressPercentText.setText("0%");

        if (!latestWeight.isEmpty()
                && !startingWeight.isEmpty()
                && isValidWeight(goal)) {

            try {
                double start = Double.parseDouble(startingWeight);
                double current = Double.parseDouble(latestWeight);
                double target = Double.parseDouble(goal);

                double totalChange = start - target;
                double completedChange = start - current;

                if (totalChange > 0) {
                    int percent = (int) Math.round(
                            (completedChange / totalChange) * 100);

                    percent = Math.max(0, Math.min(100, percent));

                    weightProgress.setProgress(percent);
                    progressPercentText.setText(percent + "%");
                }
            } catch (NumberFormatException ignored) {
                // Keep the default progress display.
            }
        }
    }

    private void sendGoalNotification(String phone, String goal) {
        pendingPhoneNumber = phone;
        pendingGoalWeight = goal;

        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST);
            return;
        }

        sendSmsNow();
    }

    private void sendSmsNow() {
        if (pendingPhoneNumber == null ||
                pendingGoalWeight == null) {
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    pendingPhoneNumber,
                    null,
                    "Congratulations! You have reached your goal weight of "
                            + pendingGoalWeight + " lbs!",
                    null,
                    null);

            goalNotificationSent = true;
            showMessage("Goal notification submitted");

        } catch (Exception e) {
            showMessage("Unable to send SMS notification");
        } finally {
            pendingPhoneNumber = null;
            pendingGoalWeight = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 &&
                    grantResults[0] ==
                            PackageManager.PERMISSION_GRANTED) {
                sendSmsNow();
            } else {
                pendingPhoneNumber = null;
                pendingGoalWeight = null;
                showMessage("SMS permission was not granted");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (dashboardVisible && databaseHelper != null) {
            refreshDashboard();
        }
    }

    private void showMessage(String message) {
        Toast.makeText(
                this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        super.onDestroy();
    }
}
