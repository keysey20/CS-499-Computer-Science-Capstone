package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_WEIGHT = "weight_history";
    private static final String COL_ID = "id";
    private static final String COL_WEIGHT = "weight";
    private static final String COL_DATE = "date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT + " TEXT NOT NULL, " +
                COL_DATE + " TEXT NOT NULL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        onCreate(db);
    }

    public boolean addWeight(String weight, String date) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT, weight);
        values.put(COL_DATE, date);

        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                TABLE_WEIGHT,
                null,
                null,
                null,
                null,
                null,
                COL_ID + " DESC"
        );
    }

    public boolean deleteWeight(int id) {
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                TABLE_WEIGHT,
                COL_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}