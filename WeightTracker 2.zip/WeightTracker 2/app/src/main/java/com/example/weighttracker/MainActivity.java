package com.example.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    100
            );
        }
        EditText username = findViewById(R.id.editUsername);
        EditText password = findViewById(R.id.editPassword);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);
        loginButton.setOnClickListener(v -> {
            String enteredUsername = username.getText().toString().trim();
            String enteredPassword = password.getText().toString();

            if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please enter your username and password",
                        Toast.LENGTH_SHORT).show();
            } else {
                SharedPreferences preferences =
                        getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE);

                String savedUsername = preferences.getString("username", "");
                String savedPassword = preferences.getString("password", "");

                if (enteredUsername.equals(savedUsername) &&
                        enteredPassword.equals(savedPassword)) {

                    Toast.makeText(MainActivity.this,
                            "Login successful",
                            Toast.LENGTH_SHORT).show();
                    setContentView(R.layout.activity_main);
                    Button historyButton = findViewById(R.id.viewHistoryButton);
                    historyButton.setOnClickListener(view -> {
                        Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                        startActivity(intent);
                    });
                    Button saveWeightButton = findViewById(R.id.saveWeightButton);
                    EditText weightInput = findViewById(R.id.weightInput);
                    EditText phoneInput = findViewById(R.id.editPhoneNumber);
                    EditText goalWeightInput = findViewById(R.id.editGoalWeight);
                    saveWeightButton.setOnClickListener(view -> {
                        String weight = weightInput.getText().toString().trim();
                        String phoneNumber = phoneInput.getText().toString().trim();
                        String goalWeight = goalWeightInput.getText().toString().trim();
                        getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE)
                                .edit()
                                .putString("phoneNumber", phoneNumber)
                                .apply();

                        if (weight.isEmpty()) {
                            Toast.makeText(MainActivity.this,
                                    "Please enter your weight",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this);

                            String date = new java.text.SimpleDateFormat(
                                    "MM/dd/yyyy",
                                    java.util.Locale.getDefault()
                            ).format(new java.util.Date());

                            boolean inserted = databaseHelper.addWeight(weight, date);

                            if (inserted) {
                                Toast.makeText(MainActivity.this,
                                        "Weight saved: " + weight + " lbs",
                                        Toast.LENGTH_SHORT).show();

                                if (!phoneNumber.isEmpty() && !goalWeight.isEmpty()) {

                                    double currentWeight = Double.parseDouble(weight);
                                    double goal = Double.parseDouble(goalWeight);

                                    if (currentWeight <= goal) {

                                        if (ActivityCompat.checkSelfPermission(
                                                MainActivity.this,
                                                Manifest.permission.SEND_SMS)
                                                == PackageManager.PERMISSION_GRANTED) {

                                            SmsManager smsManager = SmsManager.getDefault();

                                            smsManager.sendTextMessage(
                                                    phoneNumber,
                                                    null,
                                                    "Congratulations! You have reached your goal weight of "
                                                            + goalWeight + " lbs!",
                                                    null,
                                                    null
                                            );

                                            Toast.makeText(
                                                    MainActivity.this,
                                                    "Goal reached! SMS notification sent.",
                                                    Toast.LENGTH_LONG
                                            ).show();
                                        }
                                    }
                                }

                                weightInput.setText("");
                            } else {
                                Toast.makeText(MainActivity.this,
                                        "Unable to save weight",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                } else {
                    Toast.makeText(MainActivity.this,
                            "Incorrect username or password",
                            Toast.LENGTH_SHORT).show();
                }
            }

        });
        createAccountButton.setOnClickListener(v -> {
            String newUsername = username.getText().toString().trim();
            String newPassword = password.getText().toString();

            if (newUsername.isEmpty() || newPassword.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please enter a username and password",
                        Toast.LENGTH_SHORT).show();
            } else {
                SharedPreferences preferences =
                        getSharedPreferences("WeightTrackerPrefs", MODE_PRIVATE);

                preferences.edit()
                        .putString("username", newUsername)
                        .putString("password", newPassword)
                        .apply();

                Toast.makeText(MainActivity.this,
                        "Account created successfully",
                        Toast.LENGTH_SHORT).show();
            }

        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}